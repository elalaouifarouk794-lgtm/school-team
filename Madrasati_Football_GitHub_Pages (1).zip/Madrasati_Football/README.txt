# Madrasati Football

## Publier sur GitHub Pages
1. Ouvrez votre dépôt GitHub.
2. Cliquez sur **Add file** → **Create new file**.
3. Nommez le fichier `index.html`.
4. Copiez tout le contenu du fichier `index.html` de ce dossier et collez-le dans GitHub.
5. Cliquez sur **Commit changes**.
6. Dans le dépôt, ouvrez **Settings** → **Pages**.
7. Sous **Build and deployment**, choisissez **Deploy from a branch**, puis la branche `main` et le dossier `/ (root)`, puis **Save**.
8. Attendez quelques minutes et ouvrez l'adresse Pages affichée par GitHub.

## Fonctionnalités
- Interface français/arabe.
- Deux équipes et dix joueurs fournis.
- Ajout de résultats et de matchs à venir.
- Statistiques et classement calculés à partir des résultats.
- Les données sont sauvegardées dans `localStorage` du navigateur.

## Important — sécurité
Ceci est une version front-end de démonstration. Les résultats ajoutés sont enregistrés uniquement dans le navigateur utilisé et ne se synchronisent pas entre visiteurs. L'espace directeur n'est PAS protégé par une authentification. Ne mettez aucun mot de passe ou clé secrète dans ce fichier. Pour un vrai site public avec comptes et administration sécurisés, connectez un backend comme Supabase, configurez Auth et des politiques Row Level Security (RLS), puis faites vérifier les droits d'administrateur côté base de données.
